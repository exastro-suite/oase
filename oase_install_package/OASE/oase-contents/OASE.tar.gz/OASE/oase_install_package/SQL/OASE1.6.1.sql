UPDATE OASE_T_SYSTEM SET maintenance_flag=1 WHERE item_id=31;
